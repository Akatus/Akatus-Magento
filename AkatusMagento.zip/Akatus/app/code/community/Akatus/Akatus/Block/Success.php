<?php

class Akatus_Akatus_Block_Success extends Mage_Checkout_Block_Onepage_Success
{
}