<?php
/**
 * Magento Akatus Payment Modulo
 *
 * @category   Mage
 * @package    Akatus_Akatus
 * @copyright  Author 
 */



class Akatus_Akatus_Model_Resource_Mysql4_Setup extends Mage_Core_Model_Resource_Setup 
{
	
	
	
	
}

